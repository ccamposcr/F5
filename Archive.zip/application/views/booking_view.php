<!DOCTYPE html>
<html lang="en">
<head>
	<link rel="stylesheet" href="css/booking_system.css" />
	<script src="js/booking_system.js"></script>
	<meta charset="utf-8">
	<title>F5</title>
</head>
<body>
<?=$calendario?>
<input type="hidden" value="<?=$this->uri->segment(3)?>" class="year" />
<input type="hidden" value="<?=$this->uri->segment(4)?>" class="month" />
</body>
</html>